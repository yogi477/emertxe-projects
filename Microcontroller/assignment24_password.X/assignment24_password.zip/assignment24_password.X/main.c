#include <xc.h>
#include "main.h"
#include "matrix_keypad.h"
#include "clcd.h"

//void check_matrix_keypad(void)
//{
//	unsigned char key;
//	static unsigned int i;
//
//	key = read_switches(STATE_CHANGE);
//
//	if (key != ALL_RELEASED)
//	{
//		clcd_print("Key ", LINE2(1));
//		clcd_putch('0' + (key / 10), LINE2(5));
//		clcd_putch('0' + (key % 10), LINE2(6));
//		clcd_print(" Pressed ", LINE2(7));
//		//RB0 = !RB0;
//		for (i = 50000; i--;);
//	}
//	else
//	{
//		//clcd_print(" No Key Pressed ", LINE2(0));
//	}
//}

void init_config(void)
{
	init_matrix_keypad();
	init_clcd();

	clcd_print(" ENTER PASSWORD ", LINE1(0));
}

void main(void)
{
	init_config();
    unsigned char key;
	static unsigned int i = 0;
    static unsigned int j = 0;
    unsigned int flag = 0;
    char original_pass[] = "10101010";
    char user_pass[8];
	while(1)
	{
		//check_matrix_keypad();
        key = read_switches(STATE_CHANGE);
        if(i<8)
        {
           if(key == MK_SW1)
           {
               clcd_putch('*',0xC0 + i);
               user_pass[i] = '1';
               i++;
           }
           if(key == MK_SW2)
           {
              clcd_putch('*',0xC0 + i);
               user_pass[i] = '0';
               i++; 
           }
        }
	}
    for(int j=0;j<8;j++)
    {
        if(original_pass[i] != user_pass[i])
           flag = 1;
    }
            if(flag == 0)
            {
                clcd_print("SUCCESS", LINE2(0));
            }
            else
            {
               clcd_print("NO MATCH", LINE2(0)); 
            }
}
