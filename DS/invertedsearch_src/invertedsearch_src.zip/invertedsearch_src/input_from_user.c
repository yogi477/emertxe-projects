/***************************************************************************************************************************************************
*Author         :Emertxe(http://www.emertxe.com)
*Date           :Mon 22 May 2017 14:20:10 IST
*File           :input_from_user.c
*Title          :To read the input from the user.
*Description    :The search phase is going to begin. To search, collect the user input text. It should be
		:stored in a character string.
****************************************************************************************************************************************************/
#include "inverted_search.h"

char* input_from_user(void)
{
	/* Definition here */
	char *str = malloc(sizeof(char) * 20);
	printf("Enter the word you want to search: ");
	scanf(" %s",str);
	return str;		
}

